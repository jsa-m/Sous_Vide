Gerber:
Decimal 0.0001mm, Units: mm
NC Drill:
Format: 4:4, Units: mm